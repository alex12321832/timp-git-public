#include <cmath>
#include <iostream>
#include "MathLib.h"

int main()
{
    while (true)
    {
        int command = 0;

        std::cout << "\n1 Add\n2 Subtract\n3 Multiply\n4 Divide\n5 Remainder\n0 Exit\n";
        std::cout << "Choice: ";

        if (!(std::cin >> command))
        {
            std::cerr << "Invalid command input\n";
            return 1;
        }

        if (command == 0)
        {
            break;
        }

        if (command < 1 || command > 5)
        {
            std::cout << "Unknown command\n";
            continue;
        }

        if (command == 4)
        {
            double a = 0.0;
            double b = 0.0;
            std::cout << "Enter two numbers: ";

            if (!(std::cin >> a >> b))
            {
                std::cerr << "Invalid number input\n";
                return 1;
            }

            if (!std::isfinite(a) || !std::isfinite(b))
            {
                std::cerr << "Finite numbers are required\n";
                return 1;
            }

            const double result = divide(a, b);
            if (std::isnan(result))
            {
                std::cout << "Division by zero\n";
            }
            else
            {
                std::cout << "Result: " << result << '\n';
            }
            continue;
        }

        int a = 0;
        int b = 0;
        std::cout << "Enter two integers (-1000..1000): ";

        if (!(std::cin >> a >> b))
        {
            std::cerr << "Invalid integer input\n";
            return 1;
        }

        if (a < -1000 || a > 1000 || b < -1000 || b > 1000)
        {
            std::cerr << "Integer values must be in range -1000..1000\n";
            return 1;
        }

        switch (command)
        {
        case 1:
            std::cout << "Result: " << add(a, b) << '\n';
            break;
        case 2:
            std::cout << "Result: " << subtract(a, b) << '\n';
            break;
        case 3:
            std::cout << "Result: " << multiply(a, b) << '\n';
            break;
        case 5:
        {
            int result = 0;
            if (!remainder_checked(a, b, &result))
            {
                std::cout << "Remainder is undefined for a zero divisor\n";
            }
            else
            {
                std::cout << "Result: " << result << '\n';
            }
            break;
        }
        }
    }

    return 0;
}
