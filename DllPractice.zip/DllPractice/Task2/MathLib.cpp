#include "MathLib.h"
#include <limits>

int add(int a, int b)
{
    return a + b;
}

int subtract(int a, int b)
{
    return a - b;
}

int multiply(int a, int b)
{
    return a * b;
}

double divide(double a, double b)
{
    if (b == 0.0)
    {
        return std::numeric_limits<double>::quiet_NaN();
    }

    return a / b;
}

bool remainder_checked(int a, int b, int* result)
{
    if (result == nullptr || b == 0)
    {
        return false;
    }

    if (a < -1000 || a > 1000 || b < -1000 || b > 1000)
    {
        return false;
    }

    *result = a % b;
    return true;
}
