#pragma once

#ifdef MATHLIB_EXPORTS
#define MATHLIB_API __declspec(dllexport)
#else
#define MATHLIB_API __declspec(dllimport)
#endif

extern "C" MATHLIB_API int add(int a, int b);
extern "C" MATHLIB_API int subtract(int a, int b);
extern "C" MATHLIB_API int multiply(int a, int b);
extern "C" MATHLIB_API double divide(double a, double b);
extern "C" MATHLIB_API bool remainder_checked(int a, int b, int* result);
