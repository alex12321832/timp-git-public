#include <iostream>
#include "MathLib.h"

int main()
{
    int a = 0;
    int b = 0;
    std::cout << "Enter two integers: ";
    if (!(std::cin >> a >> b))
    {
        std::cerr << "Invalid input.\n";
        return 1;
    }

    if (a<-1000||a>1000||
        b<-1000||b>1000)
    {
        std::cerr << "Input values are out of bounds.\n";
        return 1;
    }
    
    std::cout << a << " + " << b << " = " << add(a, b) << '\n';
    return 0;
}

