#pragma once

#ifdef ARRAYLIB_EXPORTS
#define ARRAYLIB_API __declspec(dllexport)
#else
#define ARRAYLIB_API __declspec(dllimport)
#endif

extern "C" ARRAYLIB_API int array_sum(const int* data, int size);
extern "C" ARRAYLIB_API int array_min(const int* data, int size);
extern "C" ARRAYLIB_API int array_max(const int* data, int size);
extern "C" ARRAYLIB_API double array_average(const int* data, int size);
extern "C" ARRAYLIB_API int count_greater(const int* data, int size, int value);
