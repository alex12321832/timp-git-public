#include <iomanip>
#include <iostream>
#include "ArrayLib.h"

int main()
{
    const int first[] = { 4, -2, 7, 10, 1 };
    const int second[] = { 5 };
    const int third[] = { -4, -8, -1 };
    const int fourth[] = { 0, 0, 0 };

    struct TestCase { const char* name; const int* data; int size; };
    const TestCase cases[] = {
        { "{4,-2,7,10,1}", first, 5 },
        { "{5}", second, 1 },
        { "{-4,-8,-1}", third, 3 },
        { "{0,0,0}", fourth, 3 }
    };

    std::cout << std::left << std::setw(18) << "Array"
              << std::setw(8) << "Sum" << std::setw(8) << "Min"
              << std::setw(8) << "Max" << "Average\n";
    for (const TestCase& test : cases)
    {
        std::cout << std::left << std::setw(18) << test.name
                  << std::setw(8) << array_sum(test.data, test.size)
                  << std::setw(8) << array_min(test.data, test.size)
                  << std::setw(8) << array_max(test.data, test.size)
                  << array_average(test.data, test.size) << '\n';
    }

    std::cout << "Count greater than 3 in {4,-2,7,10,1}: "
              << count_greater(first, 5, 3) << '\n';
    return 0;
}
