#include "ArrayLib.h"
#include <limits>

int array_sum(const int* data, int size)
{
    if (data == nullptr || size <= 0) return 0;
    int total = 0;
    for (int i = 0; i < size; ++i) total += data[i];
    return total;
}

int array_min(const int* data, int size)
{
    if (data == nullptr || size <= 0) return 0;
    int result = data[0];
    for (int i = 1; i < size; ++i) if (data[i] < result) result = data[i];
    return result;
}

int array_max(const int* data, int size)
{
    if (data == nullptr || size <= 0) return 0;
    int result = data[0];
    for (int i = 1; i < size; ++i) if (data[i] > result) result = data[i];
    return result;
}

double array_average(const int* data, int size)
{
    if (data == nullptr || size <= 0) return std::numeric_limits<double>::quiet_NaN();
    return static_cast<double>(array_sum(data, size)) / size;
}

int count_greater(const int* data, int size, int value)
{
    if (data == nullptr || size <= 0) return 0;
    int count = 0;
    for (int i = 0; i < size; ++i) if (data[i] > value) ++count;
    return count;
}
